package com.authsensi.app
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
class GeneratorActivity:AppCompatActivity() {
 private var resultText=""
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_generator)
  val d=DeviceInfo.read(this); findViewById<TextView>(R.id.deviceInfo).text=d.readable()
  val styles=listOf("Rushador","Sniper","Equilibrado","Suporte")
  val aims=listOf("Arrasta","Toca","Híbrida"); val sizes=listOf("Pequena","Média","Grande")
  fun setup(id:Int, items:List<String>) { findViewById<Spinner>(id).adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,items) }
  setup(R.id.styleSpinner,styles); setup(R.id.aimSpinner,aims); setup(R.id.sizeSpinner,sizes)
  val seek=findViewById<SeekBar>(R.id.currentSensi)
  seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
   override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean) { findViewById<TextView>(R.id.currentValue).text=p.toString() }
   override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){}
  })
  findViewById<Button>(R.id.generate).setOnClickListener {
   val p=SensiGenerator.generate(d,styles[findViewById<Spinner>(R.id.styleSpinner).selectedItemPosition],aims[findViewById<Spinner>(R.id.aimSpinner).selectedItemPosition],sizes[findViewById<Spinner>(R.id.sizeSpinner).selectedItemPosition],seek.progress)
   resultText=p.formatted(); findViewById<TextView>(R.id.output).text=resultText
  }
  findViewById<Button>(R.id.copy).setOnClickListener {
   if(resultText.isBlank()) { Toast.makeText(this,"Gere uma sensibilidade primeiro.",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
   (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Auth Sensi",resultText))
   Toast.makeText(this,"Sensibilidade copiada!",Toast.LENGTH_SHORT).show()
  }
 }
}
