package com.authsensi.app

import kotlin.math.roundToInt

data class SensiProfile(val name:String, val values:Map<String,Int>, val dpi:Int) {
    fun formatted() = buildString {
        appendLine("Perfil: $name")
        values.forEach { (k,v) -> appendLine("$k: $v") }
        append("DPI recomendado: $dpi")
    }
}
object SensiGenerator {
    // Heurística inicial; sensibilidade é subjetiva e o jogo não expõe uma fórmula oficial por aparelho.
    fun generate(device:DeviceSnapshot, style:String, aim:String, screen:String, anchor:Int):SensiProfile {
        val styleFactor = when(style) { "Rushador" -> 1.12; "Sniper" -> .88; "Suporte" -> .94; else -> 1.0 }
        val aimFactor = when(aim) { "Arrasta" -> 1.06; "Toca" -> .94; else -> 1.0 }
        val screenFactor = when(screen) { "Pequena" -> 1.04; "Grande" -> .96; else -> 1.0 }
        val densityFactor = (device.dpi / 420.0).coerceIn(.78,1.22)
        val ramFactor = if(device.ramGb < 4) .96 else 1.0
        val base = (80 + anchor * 1.0) * styleFactor * aimFactor * screenFactor * (1.0 / densityFactor).coerceIn(.86,1.14)
        val g = (base * ramFactor).roundToInt().coerceIn(40,200)
        val vals = linkedMapOf(
            "Geral" to g,
            "Ponto de mira" to (g*.91).roundToInt().coerceIn(40,200),
            "Mira 2x" to (g*.82).roundToInt().coerceIn(40,200),
            "Mira 4x" to (g*.68).roundToInt().coerceIn(40,200),
            "Mira AWM" to (g*.48).roundToInt().coerceIn(40,200),
            "Olhar livre" to (g*.88).roundToInt().coerceIn(40,200)
        )
        // DPI é uma sugestão moderada baseada no DPI lógico detectado, não altera o sistema.
        val recommended = (device.dpi * if(device.ramGb < 4) .92 else 1.0).roundToInt().coerceIn(240,640)
        val suffix = style.take(3).uppercase()
        return SensiProfile("Auth-$suffix-${(anchor%90+10)}", vals, recommended)
    }
}
