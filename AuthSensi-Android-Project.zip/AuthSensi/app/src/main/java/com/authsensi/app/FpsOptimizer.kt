package com.authsensi.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Display

object FpsOptimizer {
    fun run(activity:Activity, log:(String)->Unit) {
        log("Verificando taxa de atualização...")
        val display = activity.windowManager.defaultDisplay
        val hz = display.refreshRate
        log("Tela detectada: ${"%.0f".format(hz)} Hz.")
        if(hz < 110f) log("A tela não está em 120 Hz. O aparelho/jogo pode limitar a taxa.")
        else log("Tela com taxa alta detectada.")
        log("Verificando animações do sistema...")
        // Alterar Settings.Global exige WRITE_SECURE_SETTINGS, concedida via ADB por computador.
        // O app não tenta contornar essa proteção; abre as opções oficiais do desenvolvedor.
        log("O Android protege as escalas globais de animação. Abra Opções do desenvolvedor para ajustá-las manualmente.")
        try {
            activity.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            log("Configurações do desenvolvedor abertas.")
        } catch (_:Exception) { log("Não foi possível abrir as opções do desenvolvedor.") }
        log("A limpeza global de cache de outros apps é restrita pelo Android.")
        log("O sistema gerencia processos em segundo plano; nenhum processo de outro app foi encerrado à força.")
        log("Concluído: verificações realizadas. Isso não garante 120 FPS; depende do aparelho e do jogo.")
    }
}
