package com.authsensi.app
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
class InjectorActivity:AppCompatActivity() {
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_injector)
  val check=findViewById<CheckBox>(R.id.optimizeFirst)
  findViewById<Button>(R.id.normal).setOnClickListener { if(check.isChecked) Toast.makeText(this,"Verificação leve concluída.",Toast.LENGTH_SHORT).show(); Toast.makeText(this,Injector.open(this,"com.dts.freefireth"),Toast.LENGTH_SHORT).show() }
  findViewById<Button>(R.id.max).setOnClickListener { if(check.isChecked) Toast.makeText(this,"Verificação leve concluída.",Toast.LENGTH_SHORT).show(); Toast.makeText(this,Injector.open(this,"com.dts.freefiremax"),Toast.LENGTH_SHORT).show() }
 }
}
