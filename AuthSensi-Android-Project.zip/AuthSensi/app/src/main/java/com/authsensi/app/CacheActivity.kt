package com.authsensi.app
import android.os.Bundle
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
class CacheActivity:AppCompatActivity() {
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_cache)
  findViewById<Button>(R.id.clear).setOnClickListener {
   if(Build.VERSION.SDK_INT<=28 && ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED) {
    ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE),41); return@setOnClickListener
   }
   val r=CacheCleaner.clear(this)
   val mb=(r.bytesBefore-r.bytesAfter).coerceAtLeast(0)/1024.0/1024.0
   findViewById<TextView>(R.id.status).text="${r.message}\nAntes: ${"%.2f".format(r.bytesBefore/1048576.0)} MB • Depois: ${"%.2f".format(r.bytesAfter/1048576.0)} MB"
   Toast.makeText(this,if(Build.VERSION.SDK_INT>=30) r.message else "Cache limpo: ${"%.2f".format(mb)} MB liberados",Toast.LENGTH_LONG).show()
  }
 }
}
