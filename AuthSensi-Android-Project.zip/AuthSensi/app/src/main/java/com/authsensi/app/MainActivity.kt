package com.authsensi.app
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
class MainActivity:AppCompatActivity() {
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
  findViewById<TextView>(R.id.device).text=DeviceInfo.read(this).readable()
  findViewById<Button>(R.id.generator).setOnClickListener { startActivity(Intent(this,GeneratorActivity::class.java)) }
  findViewById<Button>(R.id.optimizer).setOnClickListener { startActivity(Intent(this,OptimizerActivity::class.java)) }
  findViewById<Button>(R.id.cache).setOnClickListener { startActivity(Intent(this,CacheActivity::class.java)) }
  findViewById<Button>(R.id.injector).setOnClickListener { startActivity(Intent(this,InjectorActivity::class.java)) }
 }
}
