package com.authsensi.app

import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

data class DeviceSnapshot(val model:String, val ramGb:Double, val android:String, val dpi:Int, val widthPx:Int, val heightPx:Int, val inches:Double) {
    fun readable() = "$model • Android $android • ${"%.1f".format(ramGb)} GB RAM • ${widthPx}x$heightPx • ${dpi} dpi • ${"%.1f".format(inches)} pol."
}
object DeviceInfo {
    fun read(context: Context): DeviceSnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mem = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val diagonal = kotlin.math.sqrt((dm.widthPixels / dm.xdpi).toDouble().let { it*it } + (dm.heightPixels / dm.ydpi).toDouble().let { it*it })
        return DeviceSnapshot("${Build.MANUFACTURER} ${Build.MODEL}", mem.totalMem / 1024.0 / 1024 / 1024, Build.VERSION.RELEASE, dm.densityDpi, dm.widthPixels, dm.heightPixels, diagonal)
    }
}
