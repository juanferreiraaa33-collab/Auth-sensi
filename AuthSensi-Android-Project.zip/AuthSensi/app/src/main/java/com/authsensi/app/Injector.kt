package com.authsensi.app

import android.content.Context
import android.content.Intent

object Injector {
    fun open(context:Context, packageName:String):String {
        val launch = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return if(packageName.endsWith("freefiremax")) "Free Fire MAX não está instalado neste device" else "Free Fire Normal não está instalado neste device"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return "Abrindo o jogo..."
    }
}
