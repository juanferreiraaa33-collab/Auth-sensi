package com.authsensi.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import java.io.File

object CacheCleaner {
    data class Result(val bytesBefore:Long, val bytesAfter:Long, val message:String)
    private fun size(f:File):Long = if(!f.exists()) 0 else if(f.isFile) f.length() else f.listFiles()?.sumOf { size(it) } ?: 0
    private fun eraseContents(dir:File) {
        dir.listFiles()?.forEach { child -> if(child.isDirectory) { eraseContents(child); child.delete() } else child.delete() }
    }
    fun clear(context:Context):Result {
        // Android 11+ bloqueia acesso direto a Android/data de outros apps.
        if(Build.VERSION.SDK_INT >= 30) {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:com.dts.freefireth"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return Result(0,0,"O Android 11+ bloqueia a limpeza direta do cache de outro app. Abra Informações do Free Fire e entre em Armazenamento > Limpar cache. Repita no Free Fire MAX, se instalado.")
        }
        if(!Environment.isExternalStorageManagerCompat()) { /* caminho legado abaixo; permissão normal é solicitada pela Activity */ }
        val packages = listOf("com.dts.freefireth","com.dts.freefiremax")
        var before = 0L
        var after = 0L
        packages.forEach { pkg ->
            val dir = File(Environment.getExternalStorageDirectory(), "Android/data/$pkg/cache")
            before += size(dir)
            if(dir.exists()) eraseContents(dir)
            after += size(dir)
        }
        return Result(before,after,"Cache removido quando acessível.")
    }
}
private fun Environment.isExternalStorageManagerCompat() = true
