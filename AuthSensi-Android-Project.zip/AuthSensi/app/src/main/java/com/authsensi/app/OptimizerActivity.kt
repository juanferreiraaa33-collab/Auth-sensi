package com.authsensi.app
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
class OptimizerActivity:AppCompatActivity() {
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_optimizer)
  val log=findViewById<TextView>(R.id.log)
  findViewById<Button>(R.id.apply).setOnClickListener { log.text="Iniciando...\n"; FpsOptimizer.run(this) { line -> log.append("• $line\n") } }
 }
}
